"""Utility functions for the application."""
# Add utility functions here as needed 